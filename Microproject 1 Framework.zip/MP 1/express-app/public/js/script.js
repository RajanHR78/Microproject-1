// public/js/script.js
document.addEventListener('DOMContentLoaded', () => {
    const fetchDataBtn = document.getElementById('fetchData');
    const dataContainer = document.getElementById('dataContainer');

    fetchDataBtn.addEventListener('click', async () => {
        try {
            const response = await fetch('/api/data');
            if (!response.ok) {
                throw new Error('Failed to fetch data');
            }
            const data = await response.json();
            displayData(data);
        } catch (error) {
            console.error('Error fetching data:', error.message);
        }
    });

    function displayData(data) {
        // Clear previous data
        dataContainer.innerHTML = '';

        // Display data in a formatted manner
        const ul = document.createElement('ul');
        data.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `ID: ${item.id}, Name: ${item.name}, Price: $${item.price}`;
            ul.appendChild(li);
        });
        dataContainer.appendChild(ul);
    }
});
